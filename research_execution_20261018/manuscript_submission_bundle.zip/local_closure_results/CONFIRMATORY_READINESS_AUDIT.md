# Pre-Flight Confirmatory Protocol & Execution Readiness Audit

## 1. Candidate Confirmatory Protocols Evaluated

### Option A: Authoritative 3-Arm RCBD Protocol ($N = 72$ Runs)
- **Schedule File:** `proposed_3arm_schedule.csv` (72 rows)
- **Treatment Arms:** 3 (`ABS`, `ARIA`, `DATA-CFG`).
- **Allocation:** Exactly 24 runs per arm, 12 runs per task (T1-T6), across 4 temporal blocks of 18 runs.
- **Orthogonality:** Strictly balanced complete block design; every (arm, task) cell tested exactly once per block.
- **Multiplicity:** $\binom{3}{2} = 3$ pairwise contrasts; Bonferroni $\alpha = 0.05 / 3 = 0.0167$.
- **Methodological Strength:** Eliminates the confounded `VIS` arm (which under `use_vision=False` is observationally identical to `ABS`), completely avoiding baseline pooling dilemmas and maximizing statistical power.

### Option B: Legacy 4-Arm RCBD Protocol ($N = 96$ Runs)
- **Schedule File:** `proposed_randomized_schedule.csv` (96 rows)
- **Treatment Arms:** 4 (`ABS`, `VIS`, `ARIA`, `DATA-CFG`).
- **Allocation:** Exactly 24 runs per arm, 16 runs per task, across 4 temporal blocks of 24 runs.
- **Multiplicity:** $\binom{4}{2} = 6$ pairwise contrasts; Bonferroni $\alpha = 0.05 / 6 = 0.0083$.
### Documentary Preregistration Audit
- **Public Third-Party Registry Status:** **No Evidence of External Preregistration.** Neither protocol ($N=72$ or $N=96$) was submitted to an independent, timestamped public registry (such as the Open Science Framework [OSF], AsPredicted, or an institutional registry).
- **Internal Version Control Provenance:** Both CSV schedule files are tracked under local Git version control in `C:\testing`. While commit history proves internal freezing prior to live runs, this constitutes an *internally frozen protocol*, **not a preregistered study**. 
- **Scientific Labeling Constraint:** In the manuscript and audit documentation, these protocols must strictly be described as *internally frozen experimental designs*, never as *preregistered*.

## 2. Statistical Pipeline Offline Certification
- **Engine:** `analyze_v3_results.py`
- **Synthetic Validation:** Certified across 7 synthetic benchmark edge cases (division-by-zero, empty cells, missing runs, duplicate run IDs, quota aborts).
- **Estimators:** Cochran-Mantel-Haenszel (CMH) test for stratified risk differences and Newcombe Method 10 hybrid score intervals.
- **Verification Status:** 11/11 tests passing in `test_analyze_v3_results.py`.

## 3. Live Execution Safety Gate Status
- **Quota Ledger:** `C:\testing\research_execution_20261018\results\daily_quota_ledger.json`
- **Cumulative Requests Today:** 604 / 600
- **Cost Ceiling (USD):** $0.00
- **Halt Status:** `True` (LOCKED)
- **Safety Guarantee:** The runner strictly refuses live execution when `halted_due_to_ceiling` is true. No unexpected API consumption can occur.

## 4. Requirements Prior to Authorizing Confirmatory Live Execution
1. **Human Scope Decision:** Formally select between the 72-run 3-arm schedule (recommended) and the 96-run 4-arm schedule.
2. **Quota Reset:** If authorized, human operator must explicitly reset `daily_quota_ledger.json` (`cumulative_requests = 0`, `halted_due_to_ceiling = false`) and specify allowable ceiling (e.g., 300 requests for 72 runs at ~4 steps/run).
3. **Model API Key Authorization:** Provide authenticated API key for target model in runtime environment.
4. **Execution Command:** Launch runner via `python protocol_v3_runner.py --schedule proposed_3arm_schedule.csv`.