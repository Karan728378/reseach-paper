"""Cloud browser service integration for browser-use.

This module provides integration with the browser-use cloud browser service.
When cloud_browser=True, it automatically creates a cloud browser instance
and returns the CDP URL for connection.
"""

import logging
import os

import httpx

from browser_use.browser.cloud.views import CloudBrowserAuthError, CloudBrowserError, CloudBrowserResponse, CreateBrowserRequest
from browser_use.sync.auth import CloudAuthConfig

logger = logging.getLogger(__name__)

_BROWSER_API_VERSIONS = ('v2', 'v3', 'v4')


class CloudBrowserClient:
	"""Client for browser-use cloud browser service."""

	def __init__(self, api_base_url: str = 'https://api.browser-use.com'):
		self.api_base_url = api_base_url
		self.client = httpx.AsyncClient(timeout=30.0)
		self.current_session_id: str | None = None
		self.current_api_version: str | None = None

	@staticmethod
	def _missing_version_scope(response: httpx.Response) -> bool:
		if response.status_code != 403:
			return False
		try:
			detail = response.json().get('detail', '')
		except Exception:
			return False
		return isinstance(detail, str) and detail.startswith('API key is missing required scope:')

	async def _request_browser_api(
		self,
		method: str,
		path: str,
		*,
		headers: dict[str, str],
		json: dict,
	) -> tuple[httpx.Response, str]:
		"""Use the session's API version, or find the first version granted to this key.

		The Cloud backend mounts the same standalone-browser router under V2, V3,
		and V4, while scoped keys grant access per version. Preserve V2 behavior
		for existing keys and only fall through on the backend's explicit
		missing-version-scope response.
		"""
		# A new session may use a different scoped key. Only cleanup is pinned.
		versions = (self.current_api_version,) if method != 'POST' and self.current_api_version else _BROWSER_API_VERSIONS
		last_response = None
		last_version = versions[-1]
		for version in versions:
			url = f'{self.api_base_url}/api/{version}/browsers{path}'
			response = await self.client.request(method, url, headers=headers, json=json)
			last_response = response
			last_version = version
			if not self._missing_version_scope(response):
				return response, version
		assert last_response is not None
		return last_response, last_version

	async def create_browser(
		self, request: CreateBrowserRequest, extra_headers: dict[str, str] | None = None
	) -> CloudBrowserResponse:
		"""Create a new cloud browser instance.

		Args:
			request: CreateBrowserRequest object containing browser creation parameters

		Returns:
			CloudBrowserResponse: Contains CDP URL and other browser info
		"""
		# Try to get API key from environment variable first, then auth config
		api_token = os.getenv('BROWSER_USE_API_KEY')

		if not api_token:
			# Fallback to auth config file
			try:
				auth_config = CloudAuthConfig.load_from_file()
				api_token = auth_config.api_token
			except Exception:
				pass

		if not api_token:
			raise CloudBrowserAuthError(
				'BROWSER_USE_API_KEY is not set. To use cloud browsers, get a key at:\n'
				'https://cloud.browser-use.com/new-api-key?utm_source=oss&utm_medium=use_cloud'
			)

		headers = {'X-Browser-Use-API-Key': api_token, 'Content-Type': 'application/json', **(extra_headers or {})}

		# Convert request to dictionary and exclude unset fields
		request_body = request.model_dump(exclude_unset=True)

		try:
			logger.info('🌤️ Creating cloud browser instance...')

			response, api_version = await self._request_browser_api('POST', '', headers=headers, json=request_body)

			if response.status_code == 401:
				raise CloudBrowserAuthError(
					'BROWSER_USE_API_KEY is invalid. Get a new key at:\n'
					'https://cloud.browser-use.com/new-api-key?utm_source=oss&utm_medium=use_cloud'
				)
			elif response.status_code == 403:
				raise CloudBrowserAuthError('Access forbidden. Please check your browser-use cloud subscription status.')
			elif not response.is_success:
				error_msg = f'Failed to create cloud browser: HTTP {response.status_code}'
				try:
					error_data = response.json()
					if 'detail' in error_data:
						error_msg += f' - {error_data["detail"]}'
				except Exception:
					pass
				raise CloudBrowserError(error_msg)

			browser_data = response.json()
			browser_response = CloudBrowserResponse(**browser_data)

			# Store session ID for cleanup
			self.current_session_id = browser_response.id
			self.current_api_version = api_version

			logger.info(f'🌤️ Cloud browser created successfully: {browser_response.id}')
			logger.debug(f'🌤️ CDP URL: {browser_response.cdpUrl}')
			# Cyan color for live URL
			logger.info(f'\033[36m🔗 Live URL: {browser_response.liveUrl}\033[0m')

			return browser_response

		except httpx.TimeoutException:
			raise CloudBrowserError('Timeout while creating cloud browser. Please try again.')
		except httpx.ConnectError:
			raise CloudBrowserError('Failed to connect to cloud browser service. Please check your internet connection.')
		except Exception as e:
			if isinstance(e, (CloudBrowserError, CloudBrowserAuthError)):
				raise
			raise CloudBrowserError(f'Unexpected error creating cloud browser: {e}')

	async def stop_browser(
		self, session_id: str | None = None, extra_headers: dict[str, str] | None = None
	) -> CloudBrowserResponse:
		"""Stop a cloud browser session.

		Args:
			session_id: Session ID to stop. If None, uses current session.

		Returns:
			CloudBrowserResponse: Updated browser info with stopped status

		Raises:
			CloudBrowserAuthError: If authentication fails
			CloudBrowserError: If stopping fails
		"""
		if session_id is None:
			session_id = self.current_session_id

		if not session_id:
			raise CloudBrowserError('No session ID provided and no current session available')

		# Try to get API key from environment variable first, then auth config
		api_token = os.getenv('BROWSER_USE_API_KEY')

		if not api_token:
			# Fallback to auth config file
			try:
				auth_config = CloudAuthConfig.load_from_file()
				api_token = auth_config.api_token
			except Exception:
				pass

		if not api_token:
			raise CloudBrowserAuthError(
				'BROWSER_USE_API_KEY is not set. To use cloud browsers, get a key at:\n'
				'https://cloud.browser-use.com/new-api-key?utm_source=oss&utm_medium=use_cloud'
			)

		headers = {'X-Browser-Use-API-Key': api_token, 'Content-Type': 'application/json', **(extra_headers or {})}

		request_body = {'action': 'stop'}

		try:
			logger.info(f'🌤️ Stopping cloud browser session: {session_id}')

			response, _ = await self._request_browser_api('PATCH', f'/{session_id}', headers=headers, json=request_body)

			if response.status_code == 401:
				raise CloudBrowserAuthError(
					'Authentication failed. Please make sure you have set the BROWSER_USE_API_KEY environment variable to authenticate with the cloud service.'
				)
			elif response.status_code == 404:
				# Session already stopped or doesn't exist - treating as error and clearing session
				logger.debug(f'🌤️ Cloud browser session {session_id} not found (already stopped)')
				# Clear current session if it was this one
				if session_id == self.current_session_id:
					self.current_session_id = None
					self.current_api_version = None
				raise CloudBrowserError(f'Cloud browser session {session_id} not found')
			elif not response.is_success:
				error_msg = f'Failed to stop cloud browser: HTTP {response.status_code}'
				try:
					error_data = response.json()
					if 'detail' in error_data:
						error_msg += f' - {error_data["detail"]}'
				except Exception:
					pass
				raise CloudBrowserError(error_msg)

			browser_data = response.json()
			browser_response = CloudBrowserResponse(**browser_data)

			# Clear current session if it was this one
			if session_id == self.current_session_id:
				self.current_session_id = None
				self.current_api_version = None

			logger.info(f'🌤️ Cloud browser session stopped: {browser_response.id}')
			logger.debug(f'🌤️ Status: {browser_response.status}')

			return browser_response

		except httpx.TimeoutException:
			raise CloudBrowserError('Timeout while stopping cloud browser. Please try again.')
		except httpx.ConnectError:
			raise CloudBrowserError('Failed to connect to cloud browser service. Please check your internet connection.')
		except Exception as e:
			if isinstance(e, (CloudBrowserError, CloudBrowserAuthError)):
				raise
			raise CloudBrowserError(f'Unexpected error stopping cloud browser: {e}')

	async def close(self):
		"""Close the HTTP client and cleanup any active sessions.

		Safe to call multiple times — subsequent calls are no-ops.
		"""
		# Try to stop current session if active
		if self.current_session_id:
			try:
				await self.stop_browser()
			except Exception as e:
				logger.debug(f'Failed to stop cloud browser session during cleanup: {e}')

		if not self.client.is_closed:
			await self.client.aclose()
